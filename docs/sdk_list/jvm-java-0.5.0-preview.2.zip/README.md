# Pine Billing SDK — Windows / Java handoff

Version: **0.5.0-preview.2** (preview — compiles + unit-tests pass; not yet
validated against a real Pinelabs ISM endpoint or a real terminal).

This folder contains everything you need to integrate the Pine Billing SDK
into a Windows desktop billing app written in Java or Kotlin. No Maven /
Gradle / internet access is required at runtime — drop the four JARs from
`lib/` into your project's classpath and you're done.

---

## Folder layout

```
handoff/
├── README.md                       (this file)
├── THIRD_PARTY_NOTICES.md          (license attribution — keep alongside the JARs in your release artifact)
├── lib/                            (drop these four JARs into your project's classpath)
│   ├── pine-billing-sdk-jvm-0.5.0-preview.2.jar
│   ├── jna-5.14.0.jar
│   ├── kotlin-stdlib-2.0.20.jar
│   └── annotations-13.0.jar
└── example/
    └── SmokeTest.java              (5-line Java sanity-check program)
```

---

## Quick verification — run the smoke test

Open a Windows command prompt (cmd or PowerShell) in `handoff/example/`:

```cmd
javac -cp ".;..\lib\*" SmokeTest.java
java  -cp ".;..\lib\*" SmokeTest
```

Expected output:

```
Loader OK: extracted to C:\Users\<you>\AppData\Local\Temp\pine-billing-sdk\<sha256>\uniffi_pine_billing.dll
SDK constructed OK
AppToApp correctly rejected: AppToApp transport is Android-only; use Cloud or PADController on desktop JVM hosts.
```

If you see `UnsatisfiedLinkError`, see **Troubleshooting** below.

---

## Integration into a Java / Kotlin project (manual JAR drop)

1. Copy all four JARs from `lib/` into your project's runtime classpath
   (typically a `lib/` folder bundled with the app's release artifact).
2. Reference them on `javac` and `java` invocations:

   ```cmd
   javac -cp "lib\*" -d build src\Main.java
   java  -cp "lib\*;build" com.yourcompany.billing.Main
   ```

3. In your code, import and use:

   ```kotlin
   import org.pinelabs.billing.sdk.JvmFacade
   import uniffi.pine_billing.SdkConfig
   import uniffi.pine_billing.CloudConfig
   import uniffi.pine_billing.TransportType

   val sdk = JvmFacade(SdkConfig(
       transport = TransportType.CLOUD,
       cloud = CloudConfig(/* endpoint, credentials, etc. */),
   ))
   // sdk.doTransaction(...) etc.
   ```

   See `example/SmokeTest.java` for a minimal classpath / loader test.

> ### Kotlin vs. pure Java
>
> `SdkConfig`, `CloudConfig`, `PadControllerConfig`, `TransactionRequest`
> and a few other request types use unsigned-integer fields (`UInt`)
> that are part of the Kotlin standard library. **Pure-Java callers
> cannot construct these directly** because their primary constructors
> are only callable from Kotlin.
>
> If your billing app is pure Java, you have two options:
>
> 1. **Add a small Kotlin source file** to your project for the config
>    construction only. Mark it `@JvmStatic` and call from Java. This
>    is the recommended path; Kotlin and Java compile together with
>    no runtime cost.
> 2. **Use reflection** to invoke the synthetic constructor. Brittle
>    and not recommended.
>
> A future SDK release will add Java-friendly builders. For the
> preview, please use option 1.

---

## Java version

- Built with **JDK 11** target bytecode.
- Tested compatible with **Java 11, 17, 21**.
- Older JVMs (Java 8) will not work — they don't support some
  Kotlin-stdlib / JNA features used by the SDK.

---

## Threading

Every blocking call (`doTransaction`, `cancel`, `checkStatus`, `ping`,
`runSelfTest`, `getLogs`, `getTerminalInfo`, `uploadImeiList`, `restart`,
`connect`, `discoverTerminals`, `testPrint`) **blocks the calling thread**
until the underlying transport completes (network round-trip or socket I/O,
up to several minutes for a card-entry transaction).

**Always invoke from a worker thread / executor.** Never call from a Swing
EDT, JavaFX application thread, or any UI thread — your UI will freeze.

The core enforces a one-op-at-a-time guard so concurrent calls from
multiple threads are safe but only one will execute at a time.

---

## Transports available on Windows

| Transport     | Available on Windows                                                              |
|---------------|-----------------------------------------------------------------------------------|
| `CLOUD`       | ✅ Supported — Pinelabs ISM REST endpoint over HTTPS.                              |
| `BLUETOOTH` / `USB` / `SERIAL` (PADController) | ✅ Supported via PADController loopback (`127.0.0.1:8082` by default). Requires the PADController service to be running on the host. |
| `APP_TO_APP`  | ❌ Android-only. `setTransport(APP_TO_APP)` throws `SdkException.NotSupported`.   |
| `TCP`         | ❌ Not supported in v1.                                                            |

---

## Troubleshooting

### `no main manifest attribute, in lib\pine-billing-sdk-jvm-...jar`

You ran `java -jar lib\pine-billing-sdk-jvm-...jar`. **Don't.** This is
a *library* JAR, not an executable application — it has no `Main-Class`
because there's nothing to run standalone. Use `-cp` (classpath) and
name a class to run:

```cmd
java -cp "lib\*;build" com.yourcompany.billing.Main
```

For the bundled smoke test specifically:

```cmd
cd example
javac -cp ".;..\lib\*" SmokeTest.java
java  -cp ".;..\lib\*" SmokeTest
```

### `UnsatisfiedLinkError`

The native DLL didn't load. Most common causes:

1. **JNA missing from classpath.** Make sure `jna-5.14.0.jar` is on the
   classpath alongside the SDK JAR.

2. **Antivirus / SmartScreen quarantined the DLL.** First-run extraction
   to `%LOCALAPPDATA%\Temp\pine-billing-sdk\<sha256>\` is unsigned — some
   AV products quarantine unsigned DLLs. Whitelist the temp path or run
   the JVM with elevated privileges once to seed the extraction.

3. **Wrong JAR (32-bit JVM on 64-bit Windows or vice versa).** This SDK
   ships `windows-x86_64` only — you must run on a 64-bit JVM.

To inspect what the JAR actually contains:

```cmd
jar tf lib\pine-billing-sdk-jvm-0.5.0-preview.2.jar | findstr native\\
```

You should see exactly:

```
native/linux-x86_64/libuniffi_pine_billing.so
native/macos-aarch64/libuniffi_pine_billing.dylib
native/macos-x86_64/libuniffi_pine_billing.dylib
native/windows-x86_64/uniffi_pine_billing.dll
```

### `Invalid or corrupt jarfile ._pine-billing-sdk-jvm-...jar`

You're trying to run a macOS sidecar file. Files prefixed with `._` are
metadata sidecars created when copying from a macOS-formatted disk.
Delete the `._*` files and use the file without the prefix.

### `ClassNotFoundException: org.pinelabs.billing.sdk.JvmFacade`

Your classpath isn't picking up the SDK JAR. Verify with:

```cmd
java -cp "lib\*" -e "System.out.println(Class.forName(\"org.pinelabs.billing.sdk.JvmFacade\"))"
```

---

## Preview-build caveats

This is a **preview build**:

- ✅ Compiles and passes unit tests on macOS and Linux build hosts.
- ✅ Native DLL is a real Windows PE32+ x86-64 binary (compiled via `cross`).
- ⚠️ Has not been exercised against a real Pinelabs ISM endpoint.
- ⚠️ Has not been exercised against a real PADController daemon.
- ⚠️ Has not been exercised against a real terminal at-the-counter.

For QA / smoke / integration testing only — do **not** ship this preview
build to production. Production releases will be `0.5.0` or later, after
the smoke pass against real hardware.

---

## Need help?

Contact the SDK team with:
- Full stack trace (or `UnsatisfiedLinkError` text).
- Output of `jar tf lib\pine-billing-sdk-jvm-0.5.0-preview.2.jar | findstr native\\`.
- `java -version` output.
- `os.arch` value (`java -e "System.out.println(System.getProperty(\"os.arch\"))"`).
