// SmokeTest.java — minimum example to verify the Pine Billing SDK
// JARs load correctly on this Windows machine.
//
// This proves three things:
//   1. The classpath is wired correctly (SDK + JNA + kotlin-stdlib).
//   2. The native loader extracted libuniffi_pine_billing.dll from
//      the JAR resources to %LOCALAPPDATA%\Temp\pine-billing-sdk\.
//   3. The UniFFI types can be referenced (no class-loading errors).
//
// It does NOT instantiate JvmFacade, because real construction
// requires a real CloudConfig or PadControllerConfig with valid
// merchant credentials / endpoints — that's the integration
// developer's job, not a smoke test concern.
//
// Build:
//   javac -cp ".;..\lib\*" SmokeTest.java
//
// Run:
//   java -cp ".;..\lib\*" SmokeTest
//
// Expected output:
//   Loader OK: extracted to <some absolute path ending in .dll>
//   UniFFI types reachable: <fully-qualified class name>
//   JvmFacade reachable: <fully-qualified class name>
//   Smoke test PASSED.

import org.pinelabs.billing.sdk.JvmFacade;
import org.pinelabs.billing.sdk.internal.PineBillingSdkLoader;

public class SmokeTest {
    public static void main(String[] args) throws Exception {
        // 1. Trigger native lib extraction. This is what JvmFacade's
        //    construction would do — running it directly is the
        //    cleanest way to surface "JAR ships .dll, JVM can load it"
        //    without needing real transport config.
        PineBillingSdkLoader.ensureInitialized();
        String overridePath = System.getProperty(
            "uniffi.component.pine_billing.libraryOverride");
        if (overridePath == null) {
            System.err.println("FAIL: loader did not set uniffi.component.pine_billing.libraryOverride");
            System.exit(1);
        }
        System.out.println("Loader OK: extracted to " + overridePath);

        // 2. Verify the UniFFI-generated types are reachable on the
        //    classpath (catches "kotlin-stdlib missing" / "wrong jar"
        //    errors early).
        Class<?> sdkConfigClass = Class.forName("uniffi.pine_billing.SdkConfig");
        System.out.println("UniFFI types reachable: " + sdkConfigClass.getName());

        // 3. Verify our Java-friendly facade is reachable.
        System.out.println("JvmFacade reachable: " + JvmFacade.class.getName());

        System.out.println("Smoke test PASSED.");
    }
}

