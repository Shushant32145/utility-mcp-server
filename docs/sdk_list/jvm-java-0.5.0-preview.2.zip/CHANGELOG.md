# Pine Billing SDK (JVM) — Changelog

## 0.5.0-preview.2
- Preview build. Universal fat JAR with bundled native slices for
  windows-x86_64, macos-aarch64, macos-x86_64, linux-x86_64.
- Packaged from dist/jvm handoff for the artifact-store format.
